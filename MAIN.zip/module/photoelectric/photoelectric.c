#include "photoelectric.h"

// ��⵽��ͣ��
void photoelectric_Control(void)
{
////	if(Left==1||Right==1)
////	{
////		Car_Stop();
////		
////	}
//	if(Left==1)
////		LED1=0;
////	else if(Left==0&&Right==0)
////	{
////		Car_go();
////	}
//	else if(Left==0)
////		LED2=0;
}