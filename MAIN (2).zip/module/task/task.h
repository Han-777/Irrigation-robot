#ifndef __TASK_H
#define __TASK_H

#include "sys.h" 

void task_A(void);
void task_B(void);
void task_C(void);
void task_D(void);
void Task_Init(void);
#endif
