#ifndef __MP3_H
#define __MP3_H

#include "sys.h"
#include "openmv.h"

#define BuadRate_9600 104

#define TX_PIN GPIO_Pin_6
#define RX_PIN GPIO_Pin_15
#define TX_PORT GPIOD
#define TX_DATA_H() GPIO_SetBits(TX_PORT, TX_PIN)   // �ߵ�ƽ
#define TX_DATA_L() GPIO_ResetBits(TX_PORT, TX_PIN) // �͵�ƽ

void VirtualTx_Config(void);
void VirtualCOM_ByteSend(uint8_t Data);
void VirtualCOM_StringSend(u8 *str);
void MP3_broadcast(colorIdx mess);

#endif
