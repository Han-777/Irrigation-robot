#ifndef _OPENMV_H
#define _OPENMV_H

#include "sys.h"

extern u8 cx,cy,color,z;

int Openmv_gain();

#endif